package com.dac.theatre.controller;


import com.dac.theatre.entity.Theatre;
import com.dac.theatre.service.TheatreService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/theatres")
public class TheatreController {

    private final TheatreService service;

    public TheatreController(TheatreService service) {
        this.service = service;
    }

    @PostMapping
    public Theatre addTheatre(@RequestBody Theatre theatre) {
        return service.addTheatre(theatre);
    }

    @GetMapping
    public List<Theatre> getAll() {
        return service.getAllTheatres();
    }

    @GetMapping("/{id}")
    public Theatre getById(@PathVariable Long id) {
        return service.getTheatreById(id);
    }

    @GetMapping("/city/{city}")
    public List<Theatre> getByCity(@PathVariable String city) {
        return service.getTheatresByCity(city);
    }

    @PutMapping("/{id}")
    public Theatre update(@PathVariable Long id, @RequestBody Theatre theatre) {
        return service.updateTheatre(id, theatre);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteTheatre(id);
    }
}

