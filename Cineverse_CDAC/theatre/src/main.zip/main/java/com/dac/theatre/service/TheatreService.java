package com.dac.theatre.service;

import com.dac.theatre.entity.Theatre;
import com.dac.theatre.repository.TheatreRepository;


import com.dac.theatre.entity.Theatre;
import com.dac.theatre.repository.TheatreRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TheatreService {

    private final TheatreRepository repository;

    public TheatreService(TheatreRepository repository) {
        this.repository = repository;
    }

    public Theatre addTheatre(Theatre theatre) {
        return repository.save(theatre);
    }

    public List<Theatre> getAllTheatres() {
        return repository.findAll();
    }

    public List<Theatre> getTheatresByCity(String city) {
        return repository.findByCity(city);
    }

    public Theatre getTheatreById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Theatre not found"));
    }

    public Theatre updateTheatre(Long id, Theatre updated) {
        Theatre existing = getTheatreById(id);
        existing.setName(updated.getName());
        existing.setCity(updated.getCity());
        existing.setLocation(updated.getLocation());
        existing.setTotalScreens(updated.getTotalScreens());
        existing.setContactNumber(updated.getContactNumber());
        return repository.save(existing);
    }

    public void deleteTheatre(Long id) {
        repository.deleteById(id);
    }
}

